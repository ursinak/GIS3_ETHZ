181126_data_sensebox - collected 26.11.2018 (static); measurements every 3 min., 0:54-22:30
181203_data_sensebox - collected 03.12.2018 (static); measurements every 3 min., 22:07-2:30 + dust sensor
181204_data_sensebox - collected 04.12.2018 (kinematic); measurements every 3s, 07:40-8:00 (way from home to ETH through the forest - invalid GPS measurements!) 
181205_data_sensebox_original - collected 05.12.2018 (kinematic); measurements every 3s, 16:40-17:00 (way from ETH to home along the road - invalid GPS measurements!) 
181205_data_sensebox_gps - original data with added location 
181206_data_sensebox - collected 06.12.2018 (kinematic); measurements every 3s, 14:10-14:30 (way to ETH through the forest)

181204_walk_ETH - walk around ETH for testing GPS, measurements every 3s (not sure)